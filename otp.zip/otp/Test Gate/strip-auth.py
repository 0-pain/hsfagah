import requests

headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

data = 'billing_details[name]=+&billing_details[email]=raph%40rhp.com&billing_details[address][country]=US&billing_details[address][postal_code]=10080&type=card&card[number]=3762+453429+92002&card[cvc]=8487&card[exp_year]=29&card[exp_month]=07&allow_redisplay=unspecified&pasted_fields=number%2Ccvc&payment_user_agent=stripe.js%2Fcba9216f35%3B+stripe-js-v3%2Fcba9216f35%3B+payment-element%3B+deferred-intent&referrer=https%3A%2F%2Falmadinaperfumes.com&time_on_page=34222&client_attribution_metadata[client_session_id]=6388e824-59db-43ea-9e48-4666aab528e3&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=payment-element&client_attribution_metadata[merchant_integration_version]=2021&client_attribution_metadata[payment_intent_creation_flow]=deferred&client_attribution_metadata[payment_method_selection_flow]=merchant_specified&client_attribution_metadata[elements_session_config_id]=d0c50f41-91ef-4908-b302-0be5436ff2a2&client_attribution_metadata[merchant_integration_additional_elements][0]=payment&guid=63c54951-26cf-4b38-95c5-a839e720a4156179d6&muid=99f682e7-8ed1-47c8-8b37-4121858485ca9d187f&sid=8d04790a-ae50-48b3-877d-3b9ffb83afb06b3225&key=pk_live_51ETDmyFuiXB5oUVxaIafkGPnwuNcBxr1pXVhvLJ4BrWuiqfG6SldjatOGLQhuqXnDmgqwRA7tDoSFlbY4wFji7KR0079TvtxNs&_stripe_account=acct_1M1ZoACIoAXcQI3n&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwZCI6MCwiZXhwIjoxNzY0NTQ3ODg5LCJjZGF0YSI6IjB0UkRPSjlUdkRKZ1dVVEtxWkhqTktLWll0Qk9aV1NkZ3I3Q0FWZE1QcFJoaEsvT241NE5BbndVM0QzOEtZcUIvNzI2R3VXWTM0TjF5T3h1dk1JeWR4Nm54dzl6U1diSzdvclFIWVBnbXJJazVmWkdLci9IMVRFRGxXeW85eXFEakQvU0N3T3dmcmVUY1BhQUVoM251KzRpNDJkZ3FhNGdlVm8rOFFhNEVsZzZqMXZBTXlsRHR6dXQ4Y2t6Tmt2Y1dUMFNOazUvSEtLSTE4TVgiLCJwYXNza2V5Ijoic3lxNlNISWNCYmU3eHFGRjIvaVBqWmU3SkszOFB1NndCM2FHellycHhqV0xRTVMyTy9OWjJjd1hTMkVPblc5bXBsekJBdGk5aHRadWZpZmVrbW9TN2RFL0NET3laZFFhbjhNYW4vQm9VR3k4ZE04NUE4dEdmQnoyRG04NXJmL1l3UFJuQUdrM3NyVDFteFBETEpNam1DRCtWV2VBT1Bxbk40MzAxbzJwbzcxd3ZoYUo0RXhpYlBVLzIyU0RadmhoeER2a1lFVzZ3ZkE1UkdTQ0pzRnJIR2ZCQXlsMmlGN3pIVjNHZmN2c0ZXcFVyNUh6cThiVytqMElEOGZscXJ5bXFCWTlsL1dVRWY2dFlsa2lxZGxvYjdvbkFJRGdZaS9HdTlBVFNQNzVUZ3YyRVl2QXh6bEtzRlMzVVRUZU15cWM3QklEZUlHL0x4cEV4d1c4YUhrQkh1eEZGVnpvaXNYSURTd2ZMMzZNVGJLMUI0eWt1bW12VTBtVnRCUTJLWXEzcjd6Vmo4WWI5MVg1NDJZa3E2dkltSlRSZHVYV2VFOG05NFhqbDlzWlRKT3Rta05LV2pRaHN2TkNmQjA3UVNja003TURNRTJPclNBamFhdnNCOExzc3hSaDY3SitUNCt3WnBncSt1K1JpNkt1WW1GZk5IdjlSaENNZmhHSTJMTEJ5cnJ4ZmJmYjhpU201eDJQTmtrK2swU2hjb2JDcjNIN0x2TW1XTXBseCtBaGVZRkQ5Tk8yMitYbGNYVW1Gc09IYW9FSUYxUHZWdC9UNi8vQUNCTnpkL1cvY2EyREhyYWFBdDBwU2FnK0oxMm1YZndLcHpnNUNkT1JwTnNCdnBpeURhUUJ6K2F1YWhqZm5ram5RUERXd2dWTVZ2cnYvQnhFSmxEU2krQ0dTenJQbGUybW1pYnMvVnBJbmZmbWhpQVBINE1aQXFva1RXQlRoZ0xzejVBRTdRSktZY3d4SUNobnZOVlN3Tlg1MDJFakZ3Q3FPem9Ea3JIUjM0dXVSL0NjNCtJTzN4Wjc4UzlJeEhGenRWb0d6cTdjZnBGU0xjcTJ0N291R3NiZzEySnRiM0VwRW5DRWVxTmlGZ1FiTHpqNEs2eFFiUXozSkRyVVFyMWVpS3daZkNKeHZPRXZXN1FEUHdiVXhUbFNVV1FiRlloRXJOdkJkREVpNlVkcUlXR01FclM5dUJQVjBYTmZzUzNKQXRpVEI5RHZ0OHRQL0lpOVNOZzQxMWFmTjE4Y1lITVZqVnJ6aGg5WW9iTHhVREZLKytMT2xCUEliSUc2NlJ2NmFMclY4cDF6VVQyMkdQSnBHblZkZmF3SE0wcm4rTkh3V2FjUHQzZ3pzeGg5bmU4NVBTVlJJSVFzelVKdGMvWTd1K3VyOFdvRDlnNEVJSkUrUkIwZ3lVM1Q2V2VIRFpTR2RTRXRBdmtNMnVDMlhwTjRmRGJPNWVTRFI4eVFoblhpZ1ZMeVludm5iMUZyRGdPTXNLUHd6T28wQzdGM1l5U0I3c1U2aldLZDI4SGVSaEhldzh4Z25IU3djRmp5bVU0eW1oM3c4L0IrTmdrSmZXVTBobHpwQ1l6bGtjajczWWNidXMvbzY3YVIybkhKZHBhU2tHZzVvZVZJNnRMSFQyQ1d5WXY0a0pBVlo5SEVlQWFWK1NEUUIxNHU0NCsvTVBqSHA5MkI4MmlEd0F5Ujl6cGhBa0UvTE8wMlp1TzlTWGdydzRYdWZUQ3Z5VWhub3YyeU4rMVQ1WkxwVzdrUlVwRUNaT0ZJNVBLcTB3N2pRSi9CSGRpM1ZkUkhFdCtKT1V2QWdSOEdwaWYxd2prRFk3V28rOVpaak5wb2djdXk1WXlHSk1jekJJRmkxVFFJM1JrRk1TK0RHdjM5NUEwRXFKc2ZhdXEvNnZIMWRsaG9oSzZnZjk5cEt1eWg2V1cvWHd1V0MxSXYyK0tEd3F6RkNLTmFId3dDZXZaRERQZFFOWmRtU0xaMUw1U1NHa3F2ZDFpZ1dxSGYzTUo5eDFTYmZMdVFFS3Nqb3p3OG1DU3dCQlhQeCsySUw5dGt0aHgyaUZLU3BraENJZG95TklrRVA2Tmd2MFpVbHYzL0RGNEdCM21xWm1BSUJzR0VydExEYkZzaWJDRStXT29yZUllNEszMjMxSzJYZ0tvclFCL01lNzhPN05EMk5kTGhWd0FHZDV4R0VmTTZyR0ttSUpCY2t5VWdsTjZMcmVKSTRkMHRhRjBSWGgyQm9PT3BkYnltOUloS2VSbHg2MTZ6eVFidCtwbTZyNHVEY2lTUEgwOHN0MFNabGxwcXRBL29uc1JBSHkvVEozU0dqSFVPTnFuMTdtN0taK2hrWTFXU2JZanFhek5iVTlyRmJBZStrS3Zvd3ZTa1QrdVdOTWN0OFZ0T2FnbkcvZ0NMczdBaXJyNCtESFJsdm1meSt3NHJPZHYzNWNRZGlqcU1rWGhjRGhsTzVmRkxSa29US1NzQ0ozbGtnTmJWY3RweFVJSVJOTi9ZOHFmZ3l6bENjZlMwZCtRZkZ5VGhMcGRvNXpnblpETHNBamRlTjN0NjZnV2dCRGFWbWJhbUtPOVRyTHpWbzUwV0RrYW9CdEphdWxzN2RXai80U00wTU42Q29LZ0YzK1pGU0xJZE5YK21hRzJtRVJpdlZzeVJ1VlBVOXN5OUVpaUtnS3N4RkNNbzQ1U1pHQXBQYlVyMEJLTGdUblJ1b05pTHU5ZjVCWnR1THlQVElBPT0iLCJrciI6IjRjMDA4Zjg4Iiwic2hhcmRfaWQiOjUzNTc2NTU5fQ.8Cagryx7-8u6OVqYVJpO8egTfjReGXgsqT9WCO8ZtgU'

response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

import requests

cookies = {
    'wordpress_sec_df3be796367823040bb9affa1e228bee': 'raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C45b94881d7e68c7d9d43a0389c40117ce23f39653ef6387e619479b38c434cdb',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F',
    'sbjs_first_add': 'fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F',
    'sbjs_current': 'typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F139.0.0.0%20Mobile%20Safari%2F537.36',
    'tk_or': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'tk_r3d': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'tk_lr': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'cookieyes-consent': 'consentid:bWdlT2dySjl5TXgyMWFWVUhBQ0loT2cxbTFWUEV3Nk8,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes',
    'wordpress_logged_in_df3be796367823040bb9affa1e228bee': 'raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C0d8ba50764deefe566462238e4f52f395901812a28516bd5eec422897e37f91d',
    'tk_ai': 'X6fI2A7ea7dOlSBYM2Ga4d0g',
    '__ssid': '49d32b0f9640d0b388630b7fbb95937',
    '__stripe_mid': '99f682e7-8ed1-47c8-8b37-4121858485ca9d187f',
    '__stripe_sid': '8d04790a-ae50-48b3-877d-3b9ffb83afb06b3225',
    'sbjs_session': 'pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fmy-account%2Fadd-payment-method%2F',
    'tk_qs': '',
}

headers = {
    'authority': 'almadinaperfumes.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type': 'multipart/form-data; boundary=----WebKitFormBoundaryBbiKmTfMAq8hNrTO',
    # 'cookie': 'wordpress_sec_df3be796367823040bb9affa1e228bee=raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C45b94881d7e68c7d9d43a0389c40117ce23f39653ef6387e619479b38c434cdb; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F; sbjs_first_add=fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F; sbjs_current=typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F139.0.0.0%20Mobile%20Safari%2F537.36; tk_or=%22https%3A%2F%2Fwww.google.com%2F%22; tk_r3d=%22https%3A%2F%2Fwww.google.com%2F%22; tk_lr=%22https%3A%2F%2Fwww.google.com%2F%22; cookieyes-consent=consentid:bWdlT2dySjl5TXgyMWFWVUhBQ0loT2cxbTFWUEV3Nk8,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes; wordpress_logged_in_df3be796367823040bb9affa1e228bee=raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C0d8ba50764deefe566462238e4f52f395901812a28516bd5eec422897e37f91d; tk_ai=X6fI2A7ea7dOlSBYM2Ga4d0g; __ssid=49d32b0f9640d0b388630b7fbb95937; __stripe_mid=99f682e7-8ed1-47c8-8b37-4121858485ca9d187f; __stripe_sid=8d04790a-ae50-48b3-877d-3b9ffb83afb06b3225; sbjs_session=pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fmy-account%2Fadd-payment-method%2F; tk_qs=',
    'origin': 'https://almadinaperfumes.com',
    'referer': 'https://almadinaperfumes.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

files = {
    'action': (None, 'create_setup_intent'),
    'wcpay-payment-method': (None, 'pm_1SZKgbCIoAXcQI3nleMDdEdw'),
    '_ajax_nonce': (None, '939fa97cd8'),
}

response = requests.post('https://almadinaperfumes.com/wp-admin/admin-ajax.php', cookies=cookies, headers=headers, files=files)

import requests

cookies = {
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F',
    'sbjs_first_add': 'fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F',
    'sbjs_current': 'typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F139.0.0.0%20Mobile%20Safari%2F537.36',
    'tk_or': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'tk_r3d': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'tk_lr': '%22https%3A%2F%2Fwww.google.com%2F%22',
    'cookieyes-consent': 'consentid:bWdlT2dySjl5TXgyMWFWVUhBQ0loT2cxbTFWUEV3Nk8,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes',
    'wordpress_logged_in_df3be796367823040bb9affa1e228bee': 'raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C0d8ba50764deefe566462238e4f52f395901812a28516bd5eec422897e37f91d',
    'tk_ai': 'X6fI2A7ea7dOlSBYM2Ga4d0g',
    '__ssid': '49d32b0f9640d0b388630b7fbb95937',
    '__stripe_mid': '99f682e7-8ed1-47c8-8b37-4121858485ca9d187f',
    '__stripe_sid': '8d04790a-ae50-48b3-877d-3b9ffb83afb06b3225',
    'sbjs_session': 'pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fmy-account%2Fadd-payment-method%2F',
    'tk_qs': '',
}

headers = {
    'authority': 'almadinaperfumes.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F; sbjs_first_add=fd%3D2025-12-01%2000%3A07%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fprivacy-and-cookie-policy%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Fwww.google.com%2F; sbjs_current=typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dorganic%7C%7C%7Csrc%3Dgoogle%7C%7C%7Cmdm%3Dorganic%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F139.0.0.0%20Mobile%20Safari%2F537.36; tk_or=%22https%3A%2F%2Fwww.google.com%2F%22; tk_r3d=%22https%3A%2F%2Fwww.google.com%2F%22; tk_lr=%22https%3A%2F%2Fwww.google.com%2F%22; cookieyes-consent=consentid:bWdlT2dySjl5TXgyMWFWVUhBQ0loT2cxbTFWUEV3Nk8,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes; wordpress_logged_in_df3be796367823040bb9affa1e228bee=raph%7C1765757251%7CEByUlpoBBi6dmkccy65kGewJJjJCQ6bK6CJseOnAQ69%7C0d8ba50764deefe566462238e4f52f395901812a28516bd5eec422897e37f91d; tk_ai=X6fI2A7ea7dOlSBYM2Ga4d0g; __ssid=49d32b0f9640d0b388630b7fbb95937; __stripe_mid=99f682e7-8ed1-47c8-8b37-4121858485ca9d187f; __stripe_sid=8d04790a-ae50-48b3-877d-3b9ffb83afb06b3225; sbjs_session=pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falmadinaperfumes.com%2Fmy-account%2Fadd-payment-method%2F; tk_qs=',
    'origin': 'https://almadinaperfumes.com',
    'referer': 'https://almadinaperfumes.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}

data = {
    'payment_method': 'woocommerce_payments',
    'wc-woocommerce_payments-new-payment-method': 'true',
    'woocommerce-add-payment-method-nonce': '00b2200c55',
    '_wp_http_referer': '/my-account/add-payment-method/',
    'woocommerce_add_payment_method': '1',
    'wcpay-payment-method': 'pm_1SZKgbCIoAXcQI3nleMDdEdw',
    'wcpay-fingerprint': 'c2f7cc08bc35ce3e0e94d1c79fbae4c7',
    'wcpay-fraud-prevention-token': '',
    'wcpay-setup-intent': 'seti_1SZKgcCIoAXcQI3ngKGcHIKU',
}

response = requests.post(
    'https://almadinaperfumes.com/my-account/add-payment-method/',
    cookies=cookies,
    headers=headers,
    data=data,
)